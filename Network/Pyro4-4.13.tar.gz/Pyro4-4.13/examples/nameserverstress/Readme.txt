This example contains a stress test for the Naming Server.
It creates a bunch of threads that connect to the NS
and create/delete registrations randomly, very fast.
